# I. UX/UI Design Specification — Affiliate Content Engine (Slice 1)

**Status:** DRAFT FOR OWNER REVIEW · Version 1.0 · 2026-10-16

## 1. Design Overview

This specification describes the user interface and experience for the 10-step Affiliate Content Engine workflow. It is built on top of the functional workflow defined in Doc B and the data model in Doc D. The UI is documentation-only; no application code or production UI is implemented.

The design goals are:
- **Persistent context:** The left sidebar always lists all 10 workflow steps with current step indicator and status.
- **Workspace adaptivity:** The right workspace changes its tools and presentation according to the active step.
- **Control semantics:** Prev · Edit · Next controls are always present with consistent meaning.
- **State preservation:** Workflow state is saved so the user can pause and resume.
- **Dependency-aware invalidation:** When an upstream step changes, only downstream outputs whose dependencies changed are invalidated; stale output is never silently reused.
- **Gate semantics:** Next advances within the workflow; it does not authorize external or financial actions.

## 2. Layout Structure

### 2.1 Persistent Left Sidebar

| Element | Description |
|---|---|
| **Step list** | Vertical list of all 10 steps (Research → Work Plan → Storyboard & Script → Generate & Edit Video → Insert Text → Music & SFX → Finalize Video → Publish to Market → Monitor & Analyze → Report) |
| **Current step indicator** | Highlighted step showing which step is active; shows step number and name |
| **Step status** | Each step shows status: `NOT_STARTED`, `IN_PROGRESS`, `DRAFT_DONE`, `AWAITING_GX`, `COMPLETED`, `HALTED_QUOTA`, `HALTED_FAILURE` |
| **Progress bar** | Optional: shows fraction of completed steps (e.g., 3/10) |
| **Step tooltip** | On hover/focus, shows the step's purpose and current gate status |

### 2.2 Right Workspace

The right workspace dynamically changes its tools and presentation based on the active step number. The overall layout remains consistent, but the controls, inputs, and output area are step-specific.

| Step | Workspace Presentation |
|---|---|
| **S1 — Research** | Market research panel, evidence log browser, candidate niche cards, source verification UI |
| **S2 — Work Plan** | Experiment plan form, success criteria editor, channel/offer selector, budget guardrail |
| **S3 — Storyboard & Script** | Script editor with claim map, evidence ID selector, disclosure planner |
| **S4 — Generate & Edit Video** | Video preview/timeline, AI draft toggle, tool palette (free tools only), production metadata |
| **S5 — Insert Text** | Text overlay editor, subtitle timing, disclosure insertion, AI-assisted text draft |
| **S6 — Music & SFX** | Audio browser (free/licensed tracks), SFX selector, volume mixer, AI-assisted suggestion |
| **S7 — Finalize Video** | Final preview, export settings, asset metadata editor, tool usage summary |
| **S8 — Publish to Market** | Channel selector, caption/hashtags editor, link form selector (profile_bio/native_tag), disclosure toggles, publish kit preview |
| **S9 — Monitor & Analyze** | Observation scheduler, dashboard capture viewer, result comparison grid, M1/M2 tracker |
| **S10 — Report** | Cycle report editor, criterion verdict editor, learning archive, G5 decision form, trend status selector |

### 2.3 Persistent Controls (always visible)

| Control | Semantics | Enabled when |
|---|---|---|
| **Prev** | Reviews the prior step; loads the prior step's output into the workspace for review/editing. **Does not** advance the workflow or produce any output. | Always enabled except when current step is S1 (first step) |
| **Edit** | Changes the current step's output. In the workflow state, this transitions the step to `DRAFT_DONE` (if not already) and allows the user to modify the step's deliverables. Revisions create a new version with `version_of` linkage (old version SUPERSEDED). | Always enabled; step must be in a state that supports editing (typically `DRAFT_DONE` or `IN_PROGRESS`) |
| **Next** | Accepts/passes the current step's output to the next step. This is a **workflow advancement** action, not a blanket authorization for external or financial actions. Gating gates (G2–G5, G-pay) remain in effect. | Enabled when current step's output is valid and its gate (if any) is approved. Moves workflow to the next step. |

### 2.4 State Preservation & Pause/Resume

- The **workflow state file** (`workflow-state.yaml`) stores: `current_cycle`, `current_stage` (S1–S10), `stage_status`, `pending_action`, `last_updated`.
- When the user clicks **Prev** or **Next**, the workflow state is updated accordingly.
- When the user pauses (e.g., closes the app or switches steps), the current state is persisted.
- On resume, the workflow restores from the last saved state: the sidebar highlights the last active step, the workspace presents that step's tools, and the controls reflect the saved state.
- If an **upstream step changes** (user clicks Prev to revisit a prior step), the workflow invalidates all downstream outputs whose dependencies changed, marking them `STALE`. The user must re-run those steps to regenerate valid output.

### 2.5 Dependency-Aware Invalidation

When an upstream step is revised:

1. The workflow marks the downstream step as `STALE` in the workflow state.
2. The **Next** control for the stale step is disabled until the step is re-run.
3. The invalidation propagates only through steps whose **explicit dependencies** are affected. For example:
   - Revising S3 (Storyboard & Script) invalidates S4–S7 (video generation steps) because they depend on the script output.
   - Revising S1 (Research) invalidates S2–S10 because they depend on the opportunity brief.
4. The user must click **Edit** on each invalidated step to regenerate its output, or click **Next** to skip (if the workflow allows).
5. The workflow state records: `invalidated_by: <upstream_step_id>`, `invalidation_ts`, and `dependencies: [<list of downstream step IDs affected>]`.

### 2.6 Step-Specific UI Behaviors

#### S1 — Research (Market Scout)
- **Workspace:** Evidence log browser + candidate niche cards + source verification
- **Prev:** Disabled (S1 is the first step)
- **Edit:** Opens evidence log for review; allows adding/removing candidate briefs
- **Next:** Advances to S2 (Work Plan) if ≥3 candidates documented with sources and 1 selected with reasons (per Doc B Stage 1 acceptance); otherwise shows error summarizing missing items

#### S2 — Work Plan
- **Workspace:** Experiment plan form with hypothesis editor, success criteria table, channel/offer selector, budget guardrail (default THB 0)
- **Prev:** Loads S1 candidate brief for review
- **Edit:** Allows modifying hypothesis, success criteria, channel, link_form, budget; budget > 0 triggers G-pay gate check
- **Next:** Advances to S3 (Storyboard & Script) if G2 Experiment approved decision exists (per Doc B); otherwise shows error and lists what's needed (e.g., "G2 decision required")

#### S3 — Storyboard & Script
- **Workspace:** Script editor with claim map, evidence ID selector, disclosure planner
- **Prev:** Loads S2 experiment plan
- **Edit:** Allows adding/removing claims, mapping claims to evidence IDs, editing disclosure plan; claims without evidence are marked `kind: opinion` or `kind: UNKNOWN`; disclosure plan must be filled
- **Next:** Advances to S4 (Generate & Edit Video) if every claim is mapped (zero claims with `evidence_id: null` and `kind: fact`) and disclosure plan is present; otherwise shows error listing unmapped claims

#### S4 — Generate & Edit Video
- **Workspace:** Video preview/timeline, AI draft toggle, tool palette (free tools only), production metadata editor
- **Prev:** Loads S3 script
- **Edit:** Allows replacing AI draft with manual edits, changing tool list, adding AI-use notes; if free quota is exhausted, workflow pauses with `PAUSED_QUOTA` state and owner report
- **Next:** Advances to S5 (Insert Text) if asset file exists and production metadata records tools used, AI use, and quota state; `CostBudget.spent_thb_actual == 0` unless G-pay record exists (per Doc E AC-04)

#### S5 — Insert Text
- **Workspace:** Text overlay editor, subtitle timing, disclosure insertion, AI-assisted text draft
- **Prev:** Loads S4 asset
- **Edit:** Allows modifying text overlays, adjusting timing, changing disclosures
- **Next:** Advances to S6 (Music & SFX) if text overlays are complete and matching the script's disclosure plan

#### S6 — Music & SFX
- **Workspace:** Audio browser (free/licensed tracks), SFX selector, volume mixer, AI-assisted suggestion
- **Prev:** Loads S5 asset with text overlays
- **Edit:** Allows replacing tracks/SFX, adjusting volume; free quota exhaustion → `PAUSED_QUOTA`
- **Next:** Advances to S7 (Finalize Video) if audio assets are selected and metadata is recorded

#### S7 — Finalize Video
- **Workspace:** Final preview, export settings, asset metadata editor, tool usage summary
- **Prev:** Loads S6 asset with music/SFX
- **Edit:** Allows changing export settings, re-encoding, updating tool list; asset file must match the approved script (claim map validated)
- **Next:** Advances to S8 (Publish to Market) if asset exists, matches approved script, and production metadata is complete

#### S8 — Publish to Market
- **Workspace:** Channel selector, caption/hashtags editor, link form selector (profile_bio/native_tag/deep_link/OTHER), disclosure toggles, publish kit preview
- **Prev:** Loads S7 finalized video
- **Edit:** Allows changing channel, caption, hashtags, link form, disclosure settings; link form must be one the channel policy was verified to allow at publish time (per Doc C §6)
- **Next:** Advances to S9 (Monitor & Analyze) if G4 Publish approved decision exists (per Doc B) and publication record is complete with live_url, posted_at, link_form_used, disclosure_settings_applied, and ≥1 screenshot of the live post

#### S9 — Monitor & Analyze
- **Workspace:** Observation scheduler, dashboard capture viewer, result comparison grid, M1/M2 tracker
- **Prev:** Loads S8 publication record
- **Edit:** Allows adding/capturing new observation points (D+3, D+7, end); notes any missed windows as open questions
- **Next:** Advances to S10 (Report) if ≥3 Result observation records exist (D+3, D+7, end) with source, method, capture timestamp, and values where available (per Doc E AC-07)

#### S10 — Report
- **Workspace:** Cycle report editor, criterion verdict editor, learning archive, G5 decision form, trend status selector (Improving/Stable/Declining/Inconclusive)
- **Prev:** Loads S9 observation records
- **Edit:** Allows modifying pipeline totals, criterion verdicts, adding/removing learnings, selecting recommendation (REPEAT/REVISE/STOP), entering G5 decision rationale; all numbers must trace to ≥1 referenced ResultObservation
- **Next:** Submits the G5 decision, archives the cycle, and either starts a new cycle (REPEAT) or stops (STOP). The workflow state resets to S1 for a new cycle or marks the current cycle as ARCHIVED.

## 3. Workflow State Model Integration

The workflow state file (`data/mission1/workflow-state.yaml`) is the authoritative source of UI state. It is structured as follows:

```yaml
current_cycle: EXP-1
current_stage: S3    # S1..S10
stage_status: IN_PROGRESS   # NOT_STARTED / IN_PROGRESS / DRAFT_DONE / AWAITING_GX / HALTED_QUOTA / HALTED_FAILURE / COMPLETED
pending_action: "Revise claim map in S3 to map all facts"
last_updated: 2026-10-16T10:30:00Z

# Per-step output references (opaque IDs; actual files in docs/data)
step_outputs:
  S1:
    selected_brief: OPP-1-1
    evidence_log_ref: evidence-log.md#ev-01
  S2:
    experiment_record: EXP-1
    g2_decision: DEC-1-G2
  S3:
    script_id: SCR-1-1
    claim_map_valid: false   # becomes true after edit
  S4:
    asset_file: data/mission1/assets/video1.mp4
    quota_state: OK
  S5:
    text_overlays: ["overlay1.srt"]
  S6:
    audio_assets: ["track1.mp3", "sfx1.wav"]
  S7:
    export_profile: "youtube_short_1080p30fps"
  S8:
    publication_record: PUB-1
    live_url: "https://www.tiktok.com/@owner/video/123456789"
    link_form_used: "profile_bio"
  S9:
    observations:
      - id: OBS-1-D+3
        captured_at: 2026-10-17T10:00:00Z
      - id: OBS-1-D+7
      - id: OBS-1-END
  S10:
    cycle_report: RPT-1
    g5_decision: DEC-1-G5
    recommendation: REPEAT   # REPEAT / REVISE / STOP
```

## 4. Gate Semantics (Prev · Edit · Next)

| Gate | Controle | Meaning |
|---|---|---|
| **Prev** | Workflow regression | Loads prior step output for review; **does not** bypass any gate. The workflow state may remain in the current step until Next is explicitly clicked. |
| **Edit** | Step output modification | Allows modifying the current step's deliverables. Creates a new version (version_of linkage). Does not advance the workflow. Gating: some steps require gate approval before Edit is enabled (e.g., S3 requires claim map to have zero unmapped facts before Next is enabled). |
| **Next** | Workflow advancement | Advances the workflow to the next step. **This is not** blanket authorization for external or financial actions. All gates (G2–G5, G-pay) remain in effect. The workflow will block Next if the step's gate is not approved. |

### 4.1 Gate Enforcement

- **Next is disabled** when the current step's gate is not approved. The error message explains what's needed (e.g., "G3 approval required before Next", "G2 decision required", "G4 publish approval required").
- **Edit is always enabled** but may produce a validation warning if the modified output would violate a gate (e.g., editing S3 to remove a claim map entry that S4 depends on).
- **Prev does not bypass gates** but may show the prior step's state as it was when it was last active.

## 5. State Preservation on Interruption

If the workflow is interrupted (crash, restart, etc.):

1. The workflow state file is saved atomically on every control click (Prev/Edit/Next).
2. On restart, the workflow reads the last saved state and restores the sidebar and workspace.
3. If a step was `IN_PROGRESS` at interruption, it resumes from that state.
4. If a step was `DRAFT_DONE`, it stays in `DRAFT_DONE` and the Next control is enabled (if gate approved).
5. If a step was `HALTED_QUOTA` or `HALTED_FAILURE`, the workflow shows a halt notice in the sidebar and disables controls until the operator resolves the issue and resumes.

## 6. Evidence & Audit Trail

Every step change produces an entry in the **run history** (`run-history.yaml`):

```yaml
- ts: 2026-10-16T10:30:00Z
  actor: OWNER_OPERATOR
  action: "Clicked Next from S3 to S4"
  result: OK
- ts: 2026-10-16T10:35:00Z
  actor: OWNER_OPERATOR
  action: "Edited S4 asset; changed tool list"
  result: OK
  recovery: "Freed quota; re-imported from simpler form"
```

Every numeric value in cycle reports traces to an Evidence record ID or is explicitly tagged Unknown (per Doc D §6, Doc G OQ-8).

## 7. Terminology Check

| Term | Definition (per this spec) |
|---|---|
| **Step** | One of the 10 workflow stages (Research, Work Plan, Storyboard & Script, Generate & Edit Video, Insert Text, Music & SFX, Finalize Video, Publish to Market, Monitor & Analyze, Report) |
| **Stage** | Synonym for "step" in the functional workflow (Doc B uses "Stage 1–10") |
| **Output** | The deliverable produced at a step (brief, experiment record, script, asset, etc.) |
| **Gate** | A decision point (G1–G5, G-pay) that must be approved before the workflow can advance |
| **Prev** | Moves workflow context to the prior step for review; does not advance or approve |
| **Edit** | Modifies the current step's output; creates a new version |
| **Next** | Advances the workflow to the next step; subject to gate approval |
| **Stale** | Marked when an upstream step changes; downstream output must be re-generated |
| **Dependency-aware invalidation** | Only downstream steps whose explicit dependencies changed are invalidated |
| **Evidence record** | A tagged entry in the evidence log (Doc H format) with source, URL, retrieval date, finding, claim class |

## 8. Open Questions & Unresolved (carried from Doc G)

| # | Question | Impact on UI |
|---|---|---|
| OQ-2 | Commission-lag reality | Affects S9 observation scheduling and M1/M2 timing display |
| OQ-3 | Per-campaign commission terms | Affects S9 pipeline totals and M1 computation display |
| OQ-4 | Channel eligibility reality | Affects S8 link form selector options |
| OQ-6 | Budget > 0 appetite | Affects S2 budget field and S4/S5/S6 quota exhaustion behavior |
| OQ-7 | Which niche? | Affects S1 candidate brief display and downstream step population |

These are noted for the owner's resolution but do not prevent this UI specification from being drafted.

## 9. Revision History

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-10-16 | Codebuff (Buffy) | Initial draft for owner review |