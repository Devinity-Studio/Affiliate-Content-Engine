# J. Ten-Step Workflow Specification — Affiliate Content Engine (Slice 1)

**Status:** DRAFT FOR OWNER REVIEW · Version 1.0 · 2026-10-16

This document provides the detailed step-level specification for each of the 10 workflow steps. It is built on top of the functional workflow defined in Doc B §2 (Stage 1–10) and the data model in Doc D. For each step, it specifies: Purpose, Inputs, Outputs, User Actions, Completion Criteria/Gates, Dependencies, Failure/Recovery Path, and Evidence Required. UI behavior is described per the UX/UI Design Specification (Doc I).

## 0. Conventions

- **Gate labels:** G1–G5, G-pay refer to the gate model in Doc A §6 and Doc B §2.
- **Status values:** `NOT_STARTED`, `IN_PROGRESS`, `DRAFT_DONE`, `AWAITING_GX`, `COMPLETED`, `HALTED_QUOTA`, `HALTED_FAILURE`.
- **Versioning:** Revisions create new IDs with `version_of` linkage; old versions are SUPERSEDED.
- **Dependency-aware invalidation:** Per Doc I §2.5, revising an upstream step invalidates downstream steps whose explicit dependencies changed.
- **Evidence traceability:** Per Doc D §6 and Doc G OQ-8, every numeric value traces to an Evidence record or is explicitly Unknown.

## 1. Step 1 — Market Scout (Research)

### 1.1 Purpose
Gather market evidence about candidate niches, audience problems, products, offers, and competitor content; produce a shortlist of addressable opportunities. Per Doc B §2 S1, this is pre-G1 non-binding research using existing/free tools.

### 1.2 Inputs
- Previous cycle learnings (or none in the first cycle)
- Current affiliate-program availability (the account-referenced list in Doc C §4)
- Operator's own interests/knowledge areas

### 1.3 Outputs
- Evidence records (≥1 per key claim), filed in the evidence log
- `Opportunity brief` (draft): niche, audience, problem, candidate offers, why-now reasoning, risks, confidence level
- Exactly 1 selected niche with rationale

### 1.4 User Actions
- AI proposes 3–5 niche candidates with: audience, problem, product categories, available programs, competition notes. Every market statement tagged Fact/Inference/Hypothesis/Unknown.
- Operator verifies every source by opening the URL and confirming the finding; operator picks the shortlist.
- Unverifiable claims move to Unknown and do not drive decisions.

### 1.5 Completion Criteria/Gates
- **Gate G1 not required:** This is pre-G1 work (Doc A §7). G1 is not a prerequisite for Stage 1.
- **Acceptance:** ≥3 candidates documented with sources; 1 selected with reasons recorded; every load-bearing claim tagged (Fact/Inference/Hypothesis/Unknown).

### 1.6 Dependencies
- Outputs feed S2 (Work Plan) as the opportunity brief.
- If G1 is later recorded, pre-G1 research notes are archived but do not authorize any operational execution.

### 1.7 Failure/Recovery Path
- **Failure:** AI hallucinates a program/offer → operator verification fails → claim is marked Unknown and excluded.
- **Too few candidates:** Widen search (still zero-cost), or pause and report if key free-tool quotas are exhausted (PAUSED_QUOTA).
- **Contradiction between sources:** Record as Unknown; do not silently resolve without owner note.

### 1.8 Evidence Required
- For each key claim: source name, URL, retrieval date, exact finding, note on methodology and limitations.
- Evidence log entries with claim class tags (Fact/Inference/Hypothesis/Unknown).
- Selected niche brief with rationale and evidence IDs.

### 1.9 UI Behavior (per Doc I)
- **Sidebar:** S1 highlighted with status `IN_PROGRESS` or `DRAFT_DONE` depending on candidate count.
- **Workspace:** Evidence log browser + candidate niche cards + source verification panel.
- **Prev:** Disabled (S1 is the first step).
- **Edit:** Opens evidence log for review; allows adding/removing candidate briefs.
- **Next:** Enabled when ≥3 candidates documented with sources and 1 selected with reasons. Advances to S2 (Work Plan). Shows error summary if conditions not met.

## 2. Step 2 — Work Plan (Analysis & Forecast)

### 2.1 Purpose
Turn the selected opportunity into a clear hypothesis with explicit arithmetic and confidence. Per Doc B §2 S2, this is analysis only; G1 gates the plan as a whole, G2 then gates the specific experiment.

### 2.2 Inputs
- Opportunity brief from S1
- Program facts (commission rate, cookie/attribution window, payout terms) as verified on the program's own page/dashboard
- Operator's channel setup and capacity

### 2.3 Outputs
- `Analysis brief` with hypothesis + arithmetic + confidence + risks
- Experiment plan precursor (not yet a full experiment record; that is S3)

### 2.4 User Actions
- AI drafts the analysis: revenue hypothesis with explicit arithmetic (commission rate × conversion rate × traffic assumption × order value), each sourced or labeled ASSUMPTION.
- Operator corrects facts and approves the brief's logic before Stage 3.
- Risks and disqualifiers are stated (e.g., minimum payout threshold not reachable in experiment duration → offer is not eligible).

### 2.5 Completion Criteria/Gates
- **Gate G2 required** to proceed from analysis to experiment execution (Doc B §2, Doc A §6).
- **Acceptance:** hypothesis arithmetic explicit; every term sourced or labeled assumption; risks listed; confidence stated (L/M/H).

### 2.6 Dependencies
- Outputs feed S3 (Offer Selection & Experiment Planning) which is gated by G2.
- If G2 is not approved, the workflow reverts to S3 revision; analysis brief is archived.

### 2.7 Failure/Recovery Path
- **Failure:** hypothesis depends on unavailable data (e.g., unverified CTR) → mark Unknown, set estimate range with note that the first experiment exists to replace Unknown with Fact.
- **No eligible program:** Return to S1 with the reason logged (not a silent retry).

### 2.8 Evidence Required
- Program facts from program's own source (dashboard screenshot where available).
- Every assumption labeled as such.
- Confidence level (L/M/H) with reasons.

### 2.9 UI Behavior (per Doc I)
- **Sidebar:** S2 highlighted; status shows `AWAITING_G2` if G2 decision not yet recorded, or `DRAFT_DONE` if analysis is complete but waiting for gate.
- **Workspace:** Experiment plan form with hypothesis editor, success criteria table, channel/offer selector, budget guardrail (default THB 0).
- **Prev:** Loads S1 candidate brief for review.
- **Edit:** Allows modifying hypothesis, success criteria, channel, link_form, budget; budget > 0 triggers G-pay gate check.
- **Next:** Enabled when G2 Experiment approved decision exists (per Doc B). Advances to S3 (Storyboard & Script). Shows error "G2 decision required" if missing.

## 3. Step 3 — Storyboard & Script

### 3.1 Purpose
Draft the single content asset's script/storyboard with claim-to-evidence mapping and required disclosures. Per Doc B §2 S4, this is draft-only; final approval is via Gate G3 (Doc B §2 S6).

### 3.2 Inputs
- Experiment record from S3
- Evidence log entries for the product
- Channel policy notes (Doc C §6)
- Disclosure requirements for AI use and commercial content

### 3.3 Outputs
- `Script` v1 (in version history), claim map (claims → evidence IDs), disclosure plan
- Script status: DRAFT / DRAFT_DONE / APPROVED_G3 / REJECTED / SUPERSEDED

### 3.4 User Actions
- AI drafts script/storyboard structure (e.g., 30–60s short video: hook → problem → product demo/facts → CTA with authorized link location).
- Every factual claim in the script maps to an Evidence ID; anything not mapped is cut or rewritten as opinion clearly labeled as such.
- Include the disclosure line/setting required by the channel; note any AI-use disclosure trigger if relevant.
- Use only the authorized link form for the channel; script references link placement, not a full URL in forbidden locations.
- Operator edits the final version.

### 3.5 Completion Criteria/Gates
- **Gate G3** follows production (Doc B §2 S6), but the script must be DRAFT_DONE before production starts.
- **Acceptance:** every claim mapped (zero claims with `evidence_id: null` and `kind: fact`), disclosure included, link form authorized, operator-edited final exists.

### 3.6 Dependencies
- Outputs feed S5 (Content Production) as the script and claim map.
- S3 output is archived; revisions create new SCR versions with `version_of` linkage.

### 3.7 Failure/Recovery Path
- **Failure:** claims lack evidence → operator either supplies evidence or claim is cut; disclosure cannot be determined for the channel → treat as Unknown, do not publish, consult Doc G OQ-8 resolution path.
- **Revision loop:** If G3 rejects, revision notes → back to S4 (Doc B §2 S6) with new version.

### 3.8 Evidence Required
- Claim map: list of {claim, evidence_id | null, kind: fact|opinion}.
- Disclosure plan: {commercial, ai_use, channel_note}.
- Version identifier.

### 3.9 UI Behavior (per Doc I)
- **Sidebar:** S3 highlighted; status shows `DRAFT_DONE` when claim map has zero unmapped facts and disclosure plan is present; `IN_PROGRESS` otherwise.
- **Workspace:** Script editor with claim map, evidence ID selector, disclosure planner.
- **Prev:** Loads S2 experiment plan.
- **Edit:** Allows adding/removing claims, mapping claims to evidence IDs, editing disclosure plan; claims without evidence are marked `kind: opinion` or `kind: UNKNOWN`.
- **Next:** Enabled when every claim is mapped (zero claims with `evidence_id: null` and `kind: fact`) and disclosure plan is present. Advances to S4 (Generate & Edit Video). Shows error listing unmapped claims.

## 4. Step 4 — Generate & Edit Video

### 4.1 Purpose
Produce the approved script into one asset using free/existing tools. Per Doc B §2 S5, the operator produces the asset; AI may assist drafts of on-screen text/assets but does not render final video in Slice 1 unless a free tool is verified.

### 4.2 Inputs
- Approved script from S3
- Free tools available on the operator's computer (screen recorder, phone camera, free editors, AI tools within their free quota)

### 4.3 Outputs
- Content asset file (video/post), production metadata (tools used, AI use, quota state)
- Asset status: PRODUCING → PRODUCTION_DONE → (QA)

### 4.4 User Actions
- Operator produces the asset following the storyboard; record tool list and free-quota use.
- If a free quota is exhausted mid-production → pause and report (PAUSED_QUOTA), never silently switch to paid.
- AI may assist drafts of on-screen text/assets, but does not "render" final video in Slice 1 unless a free tool is verified.

### 4.5 Completion Criteria/Gates
- **No gate** between S4 and S5; passes directly to Stage 6 (per Doc B §2 S5).
- **Acceptance:** asset exists, matches approved script; metadata recorded.

### 4.6 Dependencies
- Outputs feed S6 (QA & Human Approval G3) as the content asset.
- If S3 (script) is revised, S4 output is invalidated per dependency-aware invalidation (Doc I §2.5).

### 4.7 Failure/Recovery Path
- **Failure:** tool unavailable/free tier blocked → fall back to a simpler asset form (e.g., a well-composed static post with product screenshots) rather than paying; record fallback in run history.
- **Quota exhaustion:** → `PAUSED_QUOTA` state; owner report; free alternatives only.

### 4.8 Evidence Required
- Asset file (path relative to repo).
- Production metadata: tools used, AI use notes, quota state during production.

### 4.9 UI Behavior (per Doc I)
- **Sidebar:** S4 highlighted; status shows `PRODUCING` during work, `PRODUCTION_DONE` when asset is complete, `HALTED_QUOTA` if quota exhausted.
- **Workspace:** Video preview/timeline, AI draft toggle, tool palette (free tools only), production metadata editor.
- **Prev:** Loads S3 script.
- **Edit:** Allows replacing AI draft with manual edits, changing tool list, adding AI-use notes; if free quota exhausted, workflow pauses with `PAUSED_QUOTA` state and owner report.
- **Next:** Enabled when asset file exists and production metadata records tools used, AI use, and quota state; `CostBudget.spent_thb_actual == 0` unless G-pay record exists (per Doc E AC-04). Advances to S5 (Insert Text).

## 5. Step 5 — Insert Text

### 5.1 Purpose
Add text overlays/subtitles to the video asset. This step completes the asset's on-screen messaging.

### 5.2 Inputs
- Asset from S4 (video with provisional or no text)

### 5.3 Outputs
- Asset with text overlays embedded, subtitle timing file, disclosure insertion for text

### 5.4 User Actions
- Operator adds text overlays, adjusting timing for readability and compliance.
- Disclosure insertion where required (per channel policy).
- AI-assisted text draft may be used but must be reviewed/edited by operator.

### 5.5 Completion Criteria/Gates
- **No explicit gate**; step flows to S6 (Music & SFX) when text overlays are complete and matching the script's disclosure plan.

### 5.6 Dependencies
- Depends on S4 asset; if S4 is invalidated, S5 must be re-run.

### 5.7 Failure/Recovery Path
- **Failure:** text expansion exceeds video safe area → reflow text or resize; free tier text tool blocked → use manual caption outside video.

### 5.8 Evidence Required
- Text overlay content and timing notes.
- Disclosure applied for text.

### 5.9 UI Behavior (per Doc I)
- **Sidebar:** S5 highlighted; status shows `IN_PROGRESS` during text insertion, `DRAFT_DONE` when complete and matching script disclosures.
- **Workspace:** Text overlay editor, subtitle timing controls, disclosure insertion panel, AI-assisted text draft toggle.
- **Prev:** Loads S4 asset with video preview.
- **Edit:** Allows modifying text overlays, adjusting timing, changing disclosures.
- **Next:** Enabled when text overlays are complete and matching the script's disclosure plan. Advances to S6 (Music & SFX). Shows error if text does not match disclosure plan.

## 6. Step 6 — Music & SFX

### 6.1 Purpose
Add background music and sound effects to the video asset.

### 6.2 Inputs
- Asset from S5 (video with text overlays)

### 6.3 Outputs
- Asset with music/SFX embedded, audio metadata (track/SFX list, volume levels, AI-use notes)

### 6.4 User Actions
- Operator selects free-licensed tracks/SFX from the audio browser.
- Volume mixing and timing alignment.
- Free quota exhaustion → `PAUSED_QUOTA`; never silently switch to paid.

### 6.5 Completion Criteria/Gates
- **No explicit gate**; step flows to S7 (Finalize Video) when audio assets are selected and metadata is recorded.

### 6.6 Dependencies
- Depends on S5 asset; if S5 is invalidated, S6 must be re-run.

### 6.7 Failure/Recovery Path
- **Failure:** free quota exhausted → `PAUSED_QUOTA`; no paid switch.
- **Unavailable track:** fall back to a different free track or silence; record fallback in run history.

### 6.8 Evidence Required
- Audio assets selected: track names, sources, license status.
- Volume levels and timing notes.
- AI-use notes if AI-assisted suggestion was used.

### 6.9 UI Behavior (per Doc I)
- **Sidebar:** S6 highlighted; status shows `IN_PROGRESS` during audio selection, `DRAFT_DONE` when complete.
- **Workspace:** Audio browser (free/licensed tracks), SFX selector, volume mixer, AI-assisted suggestion toggle.
- **Prev:** Loads S5 asset with text overlays and video preview.
- **Edit:** Allows replacing tracks/SFX, adjusting volume; free quota exhaustion → `PAUSED_QUOTA`.
- **Next:** Enabled when audio assets are selected and metadata is recorded. Advances to S7 (Finalize Video). Shows error if no audio assets selected.

## 7. Step 7 — Finalize Video

### 7.1 Purpose
Complete the video asset with export settings and final metadata. This is the last production step before publication.

### 7.2 Inputs
- Asset from S6 (video with text overlays and music/SFX)

### 7.3 Outputs
- Final video file with export profile, asset metadata editor, tool usage summary

### 7.4 User Actions
- Operator reviews the final preview, adjusts export settings (resolution, duration, format suitable for the target channel).
- Updates tool list and AI-use notes.
- Ensures the asset matches the approved script (claim map validated).

### 7.5 Completion Criteria/Gates
- **No gate** between S7 and S8; advances to S8 (Publish to Market) when asset is complete and production metadata is whole (per Doc E AC-04).

### 7.6 Dependencies
- Depends on S6 asset; if S6 is invalidated, S7 must be re-run.
- Depends on S3 script; asset must match the approved script's claim map.

### 7.7 Failure/Recovery Path
- **Failure:** export fails (platform format incompatibility) → try alternative export profile; moderation hold → retry ≤2 manually, then HALTED_FAILURE + owner report.

### 7.8 Evidence Required
- Export profile/settings.
- Final asset file path.
- Tool usage summary (updated tool list).

### 7.9 UI Behavior (per Doc I)
- **Sidebar:** S7 highlighted; status shows `IN_PROGRESS` during export, `DONE` when finalized.
- **Workspace:** Final preview, export settings panel, asset metadata editor, tool usage summary.
- **Prev:** Loads S6 asset with music/SFX.
- **Edit:** Allows changing export settings, re-encoding, updating tool list; asset must match approved script (claim map validated).
- **Next:** Enabled when asset exists, matches approved script, and production metadata is complete. Advances to S8 (Publish to Market).

## 8. Step 8 — Publish to Market

### 8.1 Purpose
Publish the approved asset on exactly one channel with the authorized affiliate link. Per Doc B §2 S7 and Doc A §7, this is manual publishing; the engine must never auto-publish.

### 8.2 Inputs
- G3-approved asset from S7
- Caption/hashtags/link kit
- Operator's channel account (affiliate program dashboard, publishing platform)
- Affiliate link from the program dashboard

### 8.3 Outputs
- `Publication record` + evidence filename(s)
- Publication status: LIVE / REMOVED / BLOCKED

### 8.4 User Actions
- Apply required platform settings (commercial-content disclosure toggles; AI-use labels where required).
- Publish the asset manually inside the platform's own app/site.
- Capture immediate evidence: live post URL, timestamp, link form used, screenshot of the live post.
- Record publication (Doc D §4).

### 8.5 Completion Criteria/Gates
- **Gate G4 required** (Doc B §2 S7, Doc A §6).
- **Acceptance:** publication record complete with evidence (live_url, posted_at, link_form_used, disclosure_settings_applied, ≥1 screenshot of the live post).

### 8.6 Dependencies
- Depends on S7 asset; if S7 is invalidated, S8 must be re-run from the revised asset.
- Depends on G3 approval (S6 in Doc B); no publication before G3.

### 8.7 Failure/Recovery Path
- **Failure:** publish fails on platform side (moderation hold, upload error) → retry manually up to 2 times, then HALTED_FAILURE + owner report; nothing auto-retries beyond that.
- **Missing disclosure setting** → do not publish; raise to owner.
- **Link form not verified** for the channel → alternative (e.g., profile link) used, or channel skipped and that fact recorded.

### 8.8 Evidence Required
- Live URL / screenshot of the live post.
- Posted timestamp (operator-recorded).
- Link form used (must match experiment's pinned link form).
- Disclosure settings applied (e.g., tiktok commercial toggle, AI label).
- Publication record (Doc D §4).

### 8.9 UI Behavior (per Doc I)
- **Sidebar:** S8 highlighted; status shows `AWAITING_G4` if G4 decision not yet recorded, `PUBLISHED_LIVE` when publication is complete.
- **Workspace:** Channel selector, caption/hashtags editor, link form selector (profile_bio/native_tag/deep_link/OTHER), disclosure toggles, publish kit preview, live post screenshot uploader.
- **Prev:** Loads S7 finalized video.
- **Edit:** Allows changing channel, caption, hashtags, link form, disclosure settings; link form must be one the channel policy was verified to allow at publish time (per Doc C §6).
- **Next:** Enabled when G4 Publish approved decision exists (per Doc B) and publication record is complete with live_url, posted_at, link_form_used, disclosure_settings_applied, and ≥1 screenshot of the live post. Advances to S9 (Monitor & Analyze). Shows error "G4 publish approval required" if missing.

## 9. Step 9 — Monitor & Analyze

### 9.1 Purpose
Collect real outcome evidence on a fixed schedule, without automation assumptions or second-guessing field meanings. Per Doc B §2 S8, observations at D+3, D+7, and experiment end.

### 9.2 Inputs
- Publication record from S8
- Program dashboard (affiliate stats)
- Platform analytics (post-level reach/clicks where available)

### 9.3 Outputs
- 3 (or more) Result observation records, evidence files
- Pipeline totals (reach → clicks → orders → pending → M1 normalized confirmed net commission → M2 cash received → costs → net income)

### 9.4 User Actions
- Scheduled captures at D+3, D+7, experiment end:
  - (a) Platform analytics screenshot/export for the relevant date range only.
  - (b) Affiliate-dashboard screenshot/export of clicks, orders, commission status, refunds — for the relevant date range only.
- Each capture becomes a Result observation record with source + method + capture timestamp.
- Distinguish: reach/engagement ≠ clicks ≠ orders ≠ commission-status values ≠ paid-out cash. Never conflate stages in reporting; capture raw dashboard values verbatim and map to normalized metrics separately (Doc D §6).

### 9.5 Completion Criteria/Gates
- **Acceptance:** observations exist for the defined schedule (D+3, D+7, end) or gaps are explicitly recorded as Unknown (per Doc E AC-07).
- **Gate G5** follows observation completion (Doc B §2 S9), but observation collection is not blocked by G5.

### 9.6 Dependencies
- Depends on S8 publication record; if S8 is invalidated, S9 must be re-run from the revised publication.
- Depends on G4 approval (S8 in Doc B); no observations for a publication that hasn't passed G4.

### 9.7 Failure/Recovery Path
- **Failure:** missed observation window → proceed with best available, but note the gap explicitly in the report; dashboard data unavailable → record Unknown + note the observation retry at the next scheduled point.
- **Dashboard fields changed** → re-derive meaning; note in run history before comparisons (per Doc B §2 S8 global failure conditions).

### 9.8 Evidence Required
- Per capture: source, method, timestamp, values (raw dashboard fields verbatim), open questions.
- Evidence files (screenshot/export paths).
- M1/M2 normalized metrics with mapping notes (Doc D §6 R1–R6).

### 9.9 UI Behavior (per Doc I)
- **Sidebar:** S9 highlighted; status shows `OBSERVING` during observation capture, `OBSERVATIONS_COMPLETE` when ≥3 observations are recorded, or `HALTED_FAILURE` if dashboard data permanently unavailable.
- **Workspace:** Observation scheduler (D+3/D+7/end calendar), dashboard capture viewer (side-by-side comparison of platform analytics + affiliate dashboard), result comparison grid (reach → clicks → orders → commission pipeline), M1/M2 tracker with mapping notes.
- **Prev:** Loads S8 publication record.
- **Edit:** Allows adding/capturing new observation points (D+3, D+7, end); notes any missed windows as open questions.
- **Next:** Enabled when ≥3 Result observation records exist (D+3, D+7, end) with source, method, capture timestamp, and values where available (per Doc E AC-07). Advances to S10 (Report). Shows error "Insufficient observations: need D+3, D+7, and end captures" if condition not met.

## 10. Step 10 — Report

### 10.1 Purpose
Compare hypothesis to actuals, extract learnings, produce the cycle report, and decide next action. Per Doc B §2 S9 and Doc E, this is the cycle report with G5 decision.

### 10.2 Inputs
- All Result observations from S9
- Experiment record (pre-registered success criteria) from S3
- Evidence log

### 10.3 Outputs
- `Cycle report` (RPT file)
- G5 decision record with rationale
- Updated learnings archive
- Objective assessment: THB 1,000/day verdict via normalized metrics and owner-agreed window (per Doc D §6 / Doc G OQ-1/Records G1-B/G1-D)
- Recommendation: REPEAT / REVISE / STOP

### 10.4 User Actions
- AI drafts the cycle report; owner reviews and decides (G5).
- Pipeline totals computed: reach → clicks → orders → pending commission → M1 normalized confirmed net commission → M2 cash received → costs → net income = M1 − costs (THB, per Doc D §6).
- Per-criterion verdicts (confirm/reject/inconclusive) against pre-registered success criteria.
- Every claim tagged Fact/Inference/Hypothesis/Unknown with references.
- Explicit list of unknowns/data gaps.
- THB 1,000/day assessment: achieved / not achieved / not yet measurable in the observation window, noting the cycle's timeline position (Weeks 1–2 learning vs Weeks 3–4 target per Doc F §0a).
- Where daily evidence is sufficient, continuous-optimization trend status: Improving / Stable / Declining / Inconclusive (per Doc F §0b / Doc G G1-E, with the "inconclusive, not blamed" rule).
- Recommendation (REPEAT/REVISE/STOP) with rationale.
- G5 decision recorded with rationale.

### 10.5 Completion Criteria/Gates
- **Gate G5** (Doc B §2 S9, Doc E AC-08).
- **Acceptance:** cycle report complete; every number in the report appears in ≥1 referenced ResultObservation; the objective assessment verdict does not contradict the numbers; decision recorded with rationale.

### 10.6 Dependencies
- Depends on S9 observation records; if S9 is invalidated, S10 must be re-run.
- Depends on G5 gate; the workflow cannot advance past S10 without a G5 decision.
- Outputs feed the next cycle: S1 (Research) begins from the previous cycle's decision, not from scratch (per Doc B §2 S10).

### 10.7 Failure/Recovery Path
- **Failure:** insufficient data for a confident decision → report says so; owner decides whether to extend observation, revise, or stop. No automatic re-run.
- **Data correction** → original OBS record remains (append-only); a new OBS/annotation references the corrected value with its own evidence file; the CycleReport cites the corrected one and notes the correction (per Doc E AC-14).

### 10.8 Evidence Required
- Each report line traces to Result Observation / Evidence IDs.
- G5 decision record with rationale.
- Learnings archive entry (tagged with class and evidence refs).
- Pipeline totals with traceability to ≥1 ResultObservation.

### 10.9 UI Behavior (per Doc I)
- **Sidebar:** S10 highlighted; status shows `DRAFTING_REPORT` while the AI is drafting, `AWAITING_G5` while the owner reviews, `DECIDED` after G5 decision recorded, `ARCHIVED` when cycle is closed.
- **Workspace:** Cycle report editor (pipeline totals, criterion verdicts, unknowns list, trend status selector, recommendation form, G5 decision rationale), learning archive browser, G5 decision form, objective assessment window editor.
- **Prev:** Loads S9 observation records for review.
- **Edit:** Allows modifying pipeline totals, criterion verdicts, adding/removing learnings, selecting recommendation (REPEAT/REVISE/STOP), entering G5 decision rationale; all numbers must trace to ≥1 referenced ResultObservation.
- **Next:** Submits the G5 decision, archives the cycle, and either starts a new cycle (REPEAT → workflow resets to S1) or stops (STOP → workflow state marks current cycle ARCHIVED). If REPEAT, the sidebar resets and S1 is re-populated with carry-forward learnings (only tagged/sourced ones per Doc B §2 S10).

## Appendix A: Workflow State Transitions Summary

| From → To | Condition | State Change |
|---|---|---|
| S1 → S2 | ≥3 candidates with sources; 1 selected with reasons | `NOT_STARTED → IN_PROGRESS → DRAFT_DONE`; then G2 gate |
| S2 → S3 | G2 Experiment approved decision exists | `DRAFT_DONE → (G2 approved) → ACTIVE_SETTING_UP` |
| S3 → S4 | Every claim mapped; disclosure present | `DRAFT_DONE → (production)` |
| S4 → S5 | Asset file exists; metadata records tools/AI/quota; spent_thb_actual == 0 unless G-pay | `PRODUCTION_DONE → (QA)` |
| S5 → S6 | Text overlays complete; matching disclosure plan | `DRAFT_DONE → (audio)` |
| S6 → S7 | Audio assets selected; metadata recorded | `DRAFT_DONE → (finalize)` |
| S7 → S8 | G4 Publish approved decision exists; publication record complete | `DONE → (publish)` |
| S8 → S9 | ≥3 OBS records (D+3, D+7, end) with source/method/timestamp/values | `OBSERVING → OBSERVATIONS_COMPLETE` |
| S9 → S10 | ≥3 observation records complete | `DRAFTING_REPORT → AWAITING_G5 → DECIDED` |
| S10 → S1 (new cycle) | G5 decision: REPEAT | workflow resets to S1 with carry-forward learnings |
| S10 → ARCHIVED | G5 decision: STOP | current cycle archived, workflow stops |

## Appendix B: Dependency Invalidation Propagation

| Upstream Step Revised | Downstream Steps Invalidated | Action Required |
|---|---|---|
| S1 (Research) | S2–S10 | Re-run from S2; carry-forward only tagged/sourced learnings |
| S2 (Work Plan) | S3–S10 | Re-run from S3; revised hypothesis propagates |
| S3 (Script) | S4–S10 | Re-run from S4; revised claim map invalidates all downstream deliverables |
| S4 (Video) | S5–S10 | Re-run from S5; revised asset invalidates text, audio, export, publish, observations, report |
| S5 (Text) | S6–S10 | Re-run from S6; revised text overlays propagate |
| S6 (Music/SFX) | S7–S10 | Re-run from S7; revised audio propagates |
| S7 (Finalize) | S8–S10 | Re-run from S8; revised export/profile propagates |
| S8 (Publish) | S9–S10 | Re-run from S9; revised publication affects observations and report |
| S9 (Monitor) | S10 | Re-run report with revised observations |
| S10 (Report) | None (archive) | Cycle archived; G5 decision recorded |

## 5. Revision History

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-10-16 | Codebuff (Buffy) | Initial draft for owner review; step-level detail added per design direction |